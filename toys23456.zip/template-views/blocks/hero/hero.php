<div class="hero">
	<div class="container">
		<div class="hero__container">
			<div class="hero__content">
				<h1 class="hero__content-title">Lorem Ipsum is simply <span>dummy text</span></h1>
				<p class="hero__content-desc">Lorem Ipsum is simply dummy text of the printing and typesetting industry.</p>
				<a class="btn" href="javascript:;">Pogledajte ponudu</a>
			</div>
			<div class="hero__main-img">
				<img src="<?php echo get_stylesheet_directory_uri(); ?>/assets/images/_demo/hero.png" alt="">
				<a class="hero__main-info" href="javascript:;">Otkrij svet najlepših<span>edukativnih igračaka</span></a>
			</div>
		</div>
	</div>
</div>