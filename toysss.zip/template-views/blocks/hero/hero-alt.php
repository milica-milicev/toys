<div class="hero hero--alt">
	<div class="container">
		<div class="hero__container">
			<div class="hero__content">
				<h1 class="hero__content-title">O nama</h1>
				<p class="hero__content-desc">Svet Igranja je nastao iz ljubavi prema našoj deci, a posebno iz njihove ljubavi prema igračkama.<br><br>Mi smo grupa roditelja koja shvata da pored toga što igračke treba da budu zabavne, u isto vreme mogu da budu i edukativne i da omoguće deci da kvalitetno provode vreme tokom igranja.</p>

			</div>
			<div class="hero__main-img">
				<img src="<?php echo get_stylesheet_directory_uri(); ?>/assets/images/_demo/about-hero.png" alt="">
			</div>
		</div>
	</div>
</div>