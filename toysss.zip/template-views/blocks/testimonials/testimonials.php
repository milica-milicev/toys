<div class="testimonials">
	<div class="container">
		<div class="section-head">
			<h2 class="section-head__title">Šta kažu roditelji</h2>
			<p class="section-head__subtitle">Ovde možete videti komentare naših zadovoljnih kupaca:</p>
		</div>
		<div class="js-swiper-testimonials testimonials__container swiper">
			<div class="swiper-wrapper">
				<div class="testimonial-item swiper-slide">
					<p class="testimonial-item__text testimonial-item__text--cupid ">Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries,</p>
					<div class="testimonial-item__bottom">
						<img src="<?php echo get_stylesheet_directory_uri(); ?>/assets/images/_demo/testimonials-1.png" alt="">
						<div class="testimonial-item__bottom-wrap">
							<p class="testimonial-item__name">Natasa Vasić</p>
							<span>Mama 2 devojčice</span>
						</div>
					</div>
                </div>
				<div class="testimonial-item swiper-slide">
					<p class="testimonial-item__text testimonial-item__text--reptide">Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries,</p>
					<div class="testimonial-item__bottom">
						<img src="<?php echo get_stylesheet_directory_uri(); ?>/assets/images/_demo/testimonials-1.png" alt="">
						<div class="testimonial-item__bottom-wrap">
							<p class="testimonial-item__name">Natasa Vasić</p>
							<span>Mama 2 devojčice</span>
						</div>
					</div>
                </div>
				<div class="testimonial-item swiper-slide">
					<p class="testimonial-item__text testimonial-item__text--robin-blue">Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries,</p>
					<div class="testimonial-item__bottom">
						<img src="<?php echo get_stylesheet_directory_uri(); ?>/assets/images/_demo/testimonials-1.png" alt="">
						<div class="testimonial-item__bottom-wrap">
							<p class="testimonial-item__name">Natasa Vasić</p>
							<span>Mama 2 devojčice</span>
						</div>
					</div>
                </div>
				<div class="testimonial-item swiper-slide">
					<p class="testimonial-item__text testimonial-item__text--cupid">Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries,</p>
					<div class="testimonial-item__bottom">
						<img src="<?php echo get_stylesheet_directory_uri(); ?>/assets/images/_demo/testimonials-1.png" alt="">
						<div class="testimonial-item__bottom-wrap">
							<p class="testimonial-item__name">Natasa Vasić</p>
							<span>Mama 2 devojčice</span>
						</div>
					</div>
                </div>
				<div class="testimonial-item swiper-slide">
					<p class="testimonial-item__text testimonial-item__text--reptide">Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries,</p>
					<div class="testimonial-item__bottom">
						<img src="<?php echo get_stylesheet_directory_uri(); ?>/assets/images/_demo/testimonials-1.png" alt="">
						<div class="testimonial-item__bottom-wrap">
							<p class="testimonial-item__name">Natasa Vasić</p>
							<span>Mama 2 devojčice</span>
						</div>
					</div>
                </div>
			</div>
			<div class="swiper-pagination"></div>
		</div>
	</div>
</div>