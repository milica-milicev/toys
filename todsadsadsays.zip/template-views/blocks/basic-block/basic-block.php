<?php
/**
 * Template View for displaying Blocks
 *
 * @package NM_Theme
 */
?>

<div class="basic-block">
	<div class="container">
		<h2 class="section-title basic-block__title">Section title</h2>
		<i class="icon font-search"></i>
		<div class="entry-content">
			Section content
		</div>
	</div>
</div><!-- .basic-block -->
