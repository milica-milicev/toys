<div class="text-block">
	<div class="container container--xs">
		<div class="entry-content">
			<h2>Naše igračke</h2>
			<p>Naš cilj je da ponudimo igračke koje će biti deo vaše porodice godinama koje dolaze, inspirišući maštu i učenje kroz igru.</p>
			<p>U našoj prodavnici možete pronaći različite igračke: od edukativnih montessori, interaktivnih, pa sve do klasičnih i zabavnih drvenih igračaka.</p>
			<p>Sve igračke su atestirane i izrađene od kvalitetnih materijala kako bi našim mališanima i onim ne tako malim omogućila sigurno i bezbedno igranje.
			</p>
		</div>
	</div>
</div>