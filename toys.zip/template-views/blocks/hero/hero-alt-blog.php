<div class="hero hero--alt">
	<div class="container">
		<div class="hero__container">
			<div class="hero__content">
				<h1 class="hero__content-title">Blog</h1>
				<p class="hero__content-desc">Lorem Ipsum is simply dummy text of the printing and typesetting industry.</p>
			</div>
			<div class="hero__main-img">
				<img src="<?php echo get_stylesheet_directory_uri(); ?>/assets/images/_demo/blog-hero.png" alt="">
			</div>
		</div>
	</div>
</div>