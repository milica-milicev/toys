<div class="recente-posts">
	<div class="container">
		<div class="section-head">
			<h2 class="section-head__title">Najnoviji blog postovi:</h2>
		</div>
		<div class="recente-posts__container">
			<div class="recente-post__item">
				<a href="javascript:;">
					<div class="recente-post__item-image">
						<img src="<?php echo get_stylesheet_directory_uri(); ?>/assets/images/_demo/recente-post1.jpg" alt="">
						<span class="recente-post__item-image-tag">Edukacija</span>
					</div>
					<h4 class="recente-post__item-title">Lorem Ipsum dollar sit amanet</h4>
					<p class="recente-post__item-desc">Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum is simply dummy text of the printing and typesetting industry.</p>
					<div class="recente-post__item-btn">
						<span class="btn">Pročitajte više</span>
					</div>
				</a>
			</div>
			<div class="recente-post__item">
				<a href="javascript:;">
					<div class="recente-post__item-image">
						<img src="<?php echo get_stylesheet_directory_uri(); ?>/assets/images/_demo/recente-post1.jpg" alt="">
						<span class="recente-post__item-image-tag">Edukacija</span>
					</div>
					<h4 class="recente-post__item-title">Lorem Ipsum dollar sit amanet</h4>
					<p class="recente-post__item-desc">Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum is simply dummy text of the printing and typesetting industry.</p>
					<div class="recente-post__item-btn">
						<span class="btn">Pročitajte više</span>
					</div>
				</a>
			</div>
			<div class="recente-post__item">
				<a href="javascript:;">
					<div class="recente-post__item-image">
						<img src="<?php echo get_stylesheet_directory_uri(); ?>/assets/images/_demo/recente-post1.jpg" alt="">
						<span class="recente-post__item-image-tag">Edukacija</span>
					</div>
					<h4 class="recente-post__item-title">Lorem Ipsum dollar sit amanet</h4>
					<p class="recente-post__item-desc">Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum is simply dummy text of the printing and typesetting industry.</p>
					<div class="recente-post__item-btn">
						<span class="btn">Pročitajte više</span>
					</div>
				</a>
			</div>
		</div>
		<div class="recente-posts__btn">
			<a class="btn btn--sec" href="/blog">Pogledaj naš ceo blog</a>
		</div>
	</div>
</div>