<div class="info">
	<div class="container">
		<div class="info__container">
			<div class="info-item">
				<img src="<?php echo get_stylesheet_directory_uri(); ?>/assets/images/_demo/garancija.svg" alt="">
				<span>Garancija</span>
			</div>
			<div class="info-item">
				<img src="<?php echo get_stylesheet_directory_uri(); ?>/assets/images/_demo/isporuka.svg" alt="">
				<span>Brza isporuka</span>
			</div>
			<div class="info-item">
				<img src="<?php echo get_stylesheet_directory_uri(); ?>/assets/images/_demo/garancija.svg" alt="">
				<span>Kvalitet</span>
			</div>
		</div>
	</div>
</div>